#!/usr/bin/env python
#-*- coding:utf-8 -*-
from .DataProcess import DataProcess
def test():
    print ("Hello, I'm wangqi.")

if __name__ == '__main__':
    test()