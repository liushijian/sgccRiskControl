# -*- coding: utf-8 -*-
import os
from openpyxl import load_workbook
import pandas as pd
from openpyxl.styles import PatternFill,Color, Style

class DataProcess():
    def __init__(self,root):
        self.root=root
    def split_table(self):
        for f in os.listdir(self.root):
            if f.endswith(".xlsx"):
                fileName=f
                f=os.path.join(self.root,f)
                wb=load_workbook(f)
                for sheetName in wb.get_sheet_names():
                    if sheetName!="Knight":
                        df=pd.read_excel(f,sheetname=sheetName)
                        companies=df["稽核对象"].drop_duplicates().iteritems()
                        for company in companies:
                            dirName=os.path.join(self.root,company[1])
                            if not os.path.exists(dirName):
                                os.mkdir(dirName)
                            filePath=os.path.join(dirName,fileName)
                            df[df["稽核对象"]==company[1]].to_excel(filePath)
    def drop_absEqual(self):
        for f in os.listdir(self.root):
            f = os.path.join(self.root, f)
            wb = load_workbook(f)
            for sheetName in wb.get_sheet_names():
                if sheetName != "Knight":
                    ws = wb[sheetName]
                    r=1
                    #ws.row_dimensions[2].style = Style(fill=PatternFill(patternType='solid', fgColor=Color('FFFF0000')))
                    #wb.save(file)



zhiGongsi = "E:\\大数据北京\\code\\拆分\\省公司、直属单位"
yiyi="E:\\大数据北京\\code\\一正一负"
d=DataProcess(yiyi)
d.drop_absEqual()
