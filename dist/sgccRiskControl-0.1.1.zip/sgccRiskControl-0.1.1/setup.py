#!/usr/bin/env python
#-*- coding:utf-8 -*-

from setuptools import setup, find_packages

setup(
    name="sgccRiskControl",
    version="0.1.1",
    packages=find_packages(),
    zip_safe=False,

    description="sgcc risk control",
    long_description="sgcc risk control",
    author="Wang Qi,Li Zhiyun",
    author_email="wangalexqi@126.com",

    license="GPL",
    keywords=["sgcc", "risk","control"],
    url="https://pypi.python.org/pypi",

)